/*
 * Pool.h
 *
 *  Created on: 17 oct. 2018
 *      Author: 3870569
 */

#ifndef POOL_H_
#define POOL_H_

#include <thread>
#include <vector>

#include "Job.h"
#include "Queue.h"

using namespace std;

class Pool
{
	Queue<Job> queue;
	vector<thread> threads;
public:
	Pool(int qs) :queue(qs) {}
	~Pool();

	void worker(Queue<Job> queue) {
		while (true) {
			Job* j = queue.pop();
			if (j == nullptr)
				return;
			j->run();
			delete j;
		}
	}

	void start(int nbt) {
		threads.reserve(nbt);
		for (int i = 0; i < nbt; ++i)
			threads.emplace_back(worker, &queue);
	}

	void submit(Job* job) {
		queue.push(job);
	}

	void stop() {
		queue.setBlockingPool(false);
		for (auto &t : threads)
			t.join();
		threads.clear();
	}
};



#endif /* POOL_H_ */
