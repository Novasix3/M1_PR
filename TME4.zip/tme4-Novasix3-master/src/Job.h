#ifndef SRC_JOB_H
#define SRC_JOB_H

class Job
{
public:
	Job();
	virtual ~Job(){}
	virtual void run() = 0;
};

#endif
