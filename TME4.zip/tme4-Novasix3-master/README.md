# TME4


Parallel ray tracing.

Compatible CDT project.

Compatible Visual Studio 2017.

Compatible autoconf/automake :
```
autoreconf -vfi
./configure 
make
```