/*
 * String.cpp
 *
 *  Created on: 26 sept. 2018
 *      Author: 3870569
 */

#include "String.h"

namespace pr{
	size_t length(const char* str){
		size_t i;
		for(i = 0; *(str+i);++i);
		return i;
	}

	char* newcopy(const char* str){
		size_t l = length(str);
		char* out = new char[l+1];
		char* temp = out;
		for(size_t i = 0; i <= l; ++i)
			*(temp+i) = *(str+i);

		return out;
	}

	String::String(const char* s){
		this->str = newcopy(s);
	}

	String::String(String s){
		this->str = newcopy(s.str);
	}

	String::~String(){
			delete [] this->str;
	}

	size_t String::length(){
		return pr::length(this->str);
	}

	std::ostream& operator<<(std::ostream &os,const String &s){
		return os <<std::endl << s.str << std::endl;
	}

	bool operator==(const String &s1,const String &s2){
		int i = 0;
		while(*(s1+i))
			i++

		return os <<std::endl << s.str << std::endl;
	}
}




