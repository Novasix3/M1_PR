/*
 * main.cpp
 *
 *  Created on: 26 sept. 2018
 *      Author: 3870569
 */

#include <iostream>

#include "String.h"

using namespace std;


int main(){
	char* str = "Hello World";
	char* str2 = pr::newcopy(str);
	cout << str << "," << &str << "," << pr::length(str) << "," << endl;
	cout << str2 << "," << &str2 << "," << pr::length(str2) << "," << endl;

	delete [] str2;

	pr::String s = pr::String("salut");
	cout<<s.length();
	cout << s;
}


