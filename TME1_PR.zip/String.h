/*
 * String
 *
 *  Created on: 26 sept. 2018
 *      Author: 3870569
 */

#ifndef STRING_H_
#define STRING_H_

#include <cstdlib>
#include <iostream>

namespace pr{
	size_t length(const char* str);
	char* newcopy(const char* str);
	class String{
		public:
			String(const char* str);
			String(String str);
			~String();
			friend std::ostream& operator<<(std::ostream &os,const String &s);
			friend std::ostream& operator==(std::ostream &os,const String &s);
			size_t length();
		private:
			char* str;
	};
}



#endif /* STRING_H_ */
