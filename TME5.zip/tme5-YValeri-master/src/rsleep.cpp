#include <ctime>
#include <cstdlib>
#include "rsleep.h"

void randsleep() {
  int r = rand();
  double ratio = (double)r / (double) RAND_MAX;
  struct timespec tosleep;
  tosleep.tv_sec =0;
  // 300 millions de ns = 0.3 secondes
  tosleep.tv_nsec = 300000000 + ratio*700000000;
  struct timespec remain;

  /*
   * nanosleep() suspend l'execution du thread courant jusqu'à ce que :
   * soit le temps défini dans tosleep est terminé
   * soit un signal déclenche un handler de ce même thread
   * dans ce cas-là, le temps restant à sleep est mis dans remain, qui est ensuite transféré à tosleep
   * cette boucle assure donc que le thread dort pendant tosleep temps
   */
  while ( nanosleep(&tosleep, &remain) != 0) {
    tosleep = remain;
  }
}
