/*#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main () {
	const int N = 3;
	pid_t mainpid = getpid();
	std::cout << "main pid=" << mainpid << std::endl;

	for (int i=1, j=N; i<=N && j==N && fork()==0 ; i++ ) {
		cout << "current pid" << getpid() << " i:j " << i << ":" << j << endl;
		for (int k=1; k<=i && j==N ; k++) {
			if ( fork() == 0) {
				j=0;
				cout << "current pid" << getpid() << " k:j " << k << ":" << j << endl;
			}
		}
	}

	Question 1 : 9 processus supplémentaires sont crées, donc 10 au total
	 * 1) i:j 1:3
	 * 2) k:j 1:0
	 * 3) i:j 2:3
	 * 4) k:j 1:0
	 * 5) i:j 3:3
	 * 6) k:j 2:0
	 * 7) k:j 3:0
	 * 8) k:j 2:0
	 * 9) k:j 1:0


	if(getpid() == mainpid){
		for(int i = 0; i < 9; ++i)
			wait(nullptr);

		cout << "fin du programme" <<endl;
	}
	return 0;
}*/
