/*
 * lost.cpp
 *
 *  Created on: 19 déc. 2018
 *      Author: yoann
 */

/*#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <semaphore.h>
#include <fcntl.h>
#include <iostream>

using namespace std;

//Question 3: tout le code

int n = 6;
int pid;

sem_t* sem_write;
sem_t* sem_read;

void send(char* buf) {
	cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;
	const char* msg[] = { "Je", "suis", "un", "vilain", "programme", "\n" };

	for (int i = 0; i < n; ++i) {

		cout << "blockage?" << endl;
		//Ajout
		sem_wait(sem_write);
		cout << " pas blockage" << endl;

		strcpy(buf, msg[i]);

		//Ajout
		sem_post(sem_read);
	}

	exit(0);
}

void receive(char* buf) {
	cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;

	cout << "receive1" << endl;

	if ((pid = fork()) == -1) {
		perror("fork");
		exit(1);
	}
	cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;

	cout << "receive2" << endl;

	for (int i = 0; i < (n / 2); ++i) {

		//Ajout
		cout << "blockage2?" << endl;
		sem_wait(sem_read);
		cout << " pas blockage2" << endl;

		printf("%s \n", buf);

		//Ajout
		sem_post(sem_write);
	}

	cout << "receive3" << endl;
}

int main00() {
	//Modif
	char* shared = (char*) mmap(0, 50, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	//Ajout
	sem_read = sem_open("/semread", O_CREAT | O_EXCL, 0666, 0);
	sem_unlink("/semread");
	sem_write = sem_open("/semwrite", O_CREAT | O_EXCL, 0666, 1);
	sem_unlink("/semwrite");
	sem_close(sem_read);
	sem_close(sem_write);
	exit(0);

	if ((pid = fork()) == -1) {
		perror("fork");
		exit(1);
	}
	cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;

	if (pid == 0)
		send(shared);
	else
		receive(shared);

	cout << "slt2" << endl;

	if (pid == 0)
		exit(0);

	for (int i = 0; i < 2; ++i)
		wait(0);

	cout << "fin du programme" << endl;

	//Ajout
	sem_close(sem_read);
	sem_close(sem_write);
	sem_unlink("/semread");
	sem_unlink("/semwrite");
	munmap(shared, 50);

	return 0;
}*/
