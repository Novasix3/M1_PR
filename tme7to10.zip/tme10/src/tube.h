/*
 * tube.h
 *
 *  Created on: 19 déc. 2018
 *      Author: yoann
 */

#ifndef TUBE_H_
#define TUBE_H_

#include <mutex>
#include <condition_variable>
#include <string.h>
#include <csignal>

#define TAILLE_PIPE 32

//Question 1 = tout le code

class tube {
	char vect[TAILLE_PIPE];
	int lect_off, ecr_off;
	int nb_char;
	int nbThreads;
	std::mutex m;
	std::condition_variable cv;
public:
	tube() :
			lect_off(0), ecr_off(0), nb_char(0), nbThreads(0) {
	}
	int read(char* buf, int n) {
		std::unique_lock<std::mutex> l(m);
		cv.wait(l, [&]() {
			return nb_char > 0;
		});

		//on aurait pu faire une boucle + modulo à partir d'ici
		n = (n < nb_char) ? n : nb_char;
		int tot = n;
		if (lect_off + n > TAILLE_PIPE) {
			auto alire = TAILLE_PIPE - lect_off;
			::memcpy(buf, vect + lect_off, alire);
			lect_off = 0;
			buf += alire;
			nb_char -= alire;
			n -= alire;
		}
		::memcpy(buf, vect + lect_off, n);
		lect_off += n;
		nb_char -= n;
		return tot;
	}

	//Question 3 :
			//utiliser des signaux en multithread ne marche pas car on ne sait pas qui va reçevoir le signal
			//on ne sait pas quel thread va reçevoir le signal, mais de toute façon il sera géré par le handler
			//processus, càd qu'il va kill le proc, et donc TOUT les threads

	int write(char* buf, int n) {
		std::unique_lock<std::mutex> l(m);

		//Question 2 : ajout de ce if
		if(nbThreads == 1)
			std::raise(SIGPIPE);


		if (n > TAILLE_PIPE - nb_char)
			return -1;
		int tot = n;
		if (ecr_off + n > TAILLE_PIPE) {
			auto aecr = TAILLE_PIPE - ecr_off;
			::memcpy(vect + ecr_off, buf, aecr);
			ecr_off = 0;
			buf += aecr;
			nb_char += aecr;
			n -= aecr;
		}
		::memcpy(vect + ecr_off, buf, n);
		ecr_off += n;
		nb_char += n;
		cv.notify_all();
		return tot;
	}
};

#endif /* TUBE_H_ */
