/*
 * lost.cpp
 *
 *  Created on: 19 déc. 2018
 *      Author: yoann
 */

#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <semaphore.h>
#include <fcntl.h>
#include <iostream>

//Question 4: tout le code

using namespace std;

int i, n = 6;
int pid;

sem_t* sem_write;
sem_t* sem_read;
sem_t* sem_read2;

void send(char* buf) {
	//cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	//cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;
	const char* msg[] = { "Je", "suis", "un", "vilain", "programme", "\n" };

	for (i = 0; i < n; ++i) {

		//cout << "blockage?" << endl;
		//cout << "trywait " << sem_trywait(sem_write) << endl;
		//Ajout
		sem_wait(sem_write);
		//cout << "pas blockage?" << endl;

		sem_wait(sem_write);
		strcpy(buf, msg[i]);
		sem_post(sem_read);

		//Ajout
		sem_post(sem_read2);
	}

	exit(0);
}

void receive(char* buf) {
	//cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	//cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;
	if ((pid = fork()) == -1) {
		perror("fork");
		exit(1);
	}
	//cout << "sem_read pour "<< getpid() << " = " << sem_read << endl;
	//cout << "sem_write pour "<< getpid() << " = " << sem_write << endl;

	for (i = 0; i < n; ++i) {

		//cout << "blockage2?" << endl;
		//cout << "trywait before read" << sem_trywait(sem_read) << endl;
		//Ajout
		if(pid != 0)
			sem_wait(sem_read);
		else
			sem_wait(sem_read2);
		//cout << "pas blockage2?" << endl;

		//Modif
		//sem_wait(sem_write);

		printf("%s\n", buf);
		cout << "kéblo avant le sem post de write\n";
		sem_post(sem_write);
	}
}

int main() {
	//Modif
	char* shared = (char*) mmap(0, 50, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
	//Ajout
	sem_read = sem_open("/semread", O_CREAT, 0666, 0);
	sem_read2 = sem_open("/semread2", O_CREAT, 0666, 0);
	sem_write = sem_open("/semwrite", O_CREAT, 0666, 2);


	/*cout << "trywait before write" << sem_trywait(sem_write) << endl;
	cout << "trywait before read" << sem_trywait(sem_read) << endl;
	cout << "trywait before read2" << sem_trywait(sem_read2) << endl;*/


	if ((pid = fork()) == -1) {
		perror("fork");
		exit(1);
	}

	if (pid == 0)
		send(shared);
	else
		receive(shared);

	if (pid == 0)
		exit(0);

	for (i = 0; i < 2; ++i)
		wait(0);

	printf("fin du programme\n");

	//Ajout
	sem_close(sem_read);
	sem_close(sem_read2);
	sem_close(sem_write);
	sem_unlink("/semread");
	sem_unlink("/semread2");
	sem_unlink("/semwrite");
	munmap(shared, 50);

	return 0;
}
