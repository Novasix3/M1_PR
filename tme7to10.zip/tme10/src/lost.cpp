/*
 * lost.cpp
 *
 *  Created on: 19 déc. 2018
 *      Author: yoann
 */

/*#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <cstdlib>
#include <cstdio>
#include <cstring>

int i, n = 6;
int pid;

void send(char* buf) {
	const char* msg[] = { "Je", "suis", "un", "vilain", "programme", "\n" };
	for (i = 0; i < n; ++i)
		strcpy(buf, msg[i]);

	exit(0);
}

void receive(char* buf) {
	if ((pid = fork()) == -1) {
		perror("fork");
		exit(1);
	}
	for (i = 0; i < n / 2; ++i)
		printf("%s", buf);
}

//Question 1:
//deux proc sont créés, l'un fera send, l'autre fera, avec le proc principal, receive
//donc 3 procs au total

//Question 2:
//Cela ne marchera pas car il n'y a aucune mémoire partagée, et même s'il y en avait
//aucune synchro entre les procs, donc ils feraient tous n'importe quoi

int main0() {
	char* shared = new char[50];
	if ((pid = fork()) == -1) {
		perror("fork");
		exit(1);
	}

	if (pid == 0)
		send(shared);
	else
		receive(shared);

	if (pid == 0)
		exit(0);

	for (i = 0; i < 2; ++i)
		wait(0);

	printf("fin du programme\n");
	delete[] shared;
	return 0;
}*/
