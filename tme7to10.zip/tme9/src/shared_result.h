/*
 * future.h
 *
 *  Created on: 12 déc. 2018
 *      Author: yoann
 */

#ifndef SRC_SHARED_RESULT_H_
#define SRC_SHARED_RESULT_H_

#include <mutex>
#include <condition_variable>

using namespace std;

namespace pr {
	template<typename T>
	class shared_result {
		T res;
		bool isSet;
		mutex m;
		condition_variable cv;
	public:
		shared_result<T>():res(), isSet(false) {}
		T get() {
			unique_lock<mutex> lu(m);
			while (!is_set())
				cv.wait(lu);
			isSet = false;
			return move(res);
		}
		bool is_set() const {
			return isSet;
		}
		void set(const T &val) {
			{
				unique_lock<mutex> lu(m);
				//res = val;
				res = move(val);
				isSet = true;
			}
			cv.notify_one();
		}
	};
}

#endif /* SRC_SHARED_RESULT_H_ */
