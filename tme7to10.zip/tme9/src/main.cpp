#include "Pool.h"
#include "future.h"
#include <unistd.h>
#include <iostream>
#include <vector>

using namespace pr;
using namespace std;

class SleepJob:public Job<int>{
	int val;
public:
	SleepJob():val(getpid()){}
	int run(){
		return val;
	}
};

int main() {
	int NBTHREADS = 5;
	int NBJOBS = 30;
	Pool<int> pool(NBTHREADS);
	pool.start(NBTHREADS);
	vector<future<int>> results;

	for(int i = 0; i < NBJOBS; ++i)
		results.emplace_back(pool.submit(new SleepJob()));

	for(auto& i : results)
		cout << i.get() << endl;

	cout << "slt" << endl;
	pool.stop();
	return 0;

}
