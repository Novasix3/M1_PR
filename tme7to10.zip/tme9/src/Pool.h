#ifndef SRC_POOL_H_
#define SRC_POOL_H_

#include "Queue.h"
#include "promise.h"
#include "future.h"
#include <vector>
#include <thread>

namespace pr {

	template<typename T>
	class Job {
	public:
		virtual T run() = 0;
		virtual ~Job() {};
	};

	template<typename T>
	class PackagedTask{
		Job<T>* job;
		promise<T> result;
	public:
		PackagedTask(Job<T>* job):job(job){}
		promise<T> &getPromise(){
			return result;
		}
		Job<T>* getJob(){
			return job;
		}
		~PackagedTask(){
			delete job;
		}
	};

	template<typename T>
	// fonction passee a ctor de  thread
	inline void poolWorker(Queue<PackagedTask<T>> * queue) {
		while (true) {
			PackagedTask<T>* task = queue->pop();

			// NB : ajout en fin de TD pour la terminaison propre
			if (task == nullptr)
				// on est non bloquant = il faut sortir
				return;

			Job<T>* job = task->getJob();
			task->getPromise().setValue(job->run());

			delete task;
		}
	}

	template<typename T>
	class Pool {
		Queue<PackagedTask<T>> queue;
		std::vector<std::thread> threads;
	public:
		Pool(int qsize) :
				queue(qsize) {
		}
		void start(int nbthread) {
			threads.reserve(nbthread);
			for (int i = 0; i < nbthread; i++) {
				threads.emplace_back(poolWorker<T>, &queue);
			}
		}
		// Ajout a la fin du TD, pour la terminaison
		void stop() {
			queue.setBlocking(false);
			for (auto & t : threads) {
				t.join();
			}
			threads.clear();
		}
		~Pool() {
			stop();
		}
		future<T> submit(Job<T> * job) {
			PackagedTask<T>* t = new PackagedTask<T>(job);
			queue.push(t);
			return t->getPromise().getFuture();
		}
	};

} /* namespace pr */

#endif /* SRC_POOL_H_ */
