/*
 * future.h
 *
 *  Created on: 12 déc. 2018
 *      Author: yoann
 */

#ifndef SRC_FUTURE_H_
#define SRC_FUTURE_H_

#include <mutex>
#include <condition_variable>
#include <memory>

#include "shared_result.h"

using namespace std;

/*template<class T>
using Resptr = pr:shared_result<T>*;*/

template <typename T>
using Resptr = shared_ptr<pr::shared_result<T>>;

namespace pr{
	template <typename T>
	class future{
		Resptr<T> result;
	public:
		future(const Resptr<T> &res):result(res){}
		T get(){
			return result->get();
		}
		bool isAvailable() const{
			return result->is_set();
		}
	};
}



#endif /* SRC_FUTURE_H_ */
