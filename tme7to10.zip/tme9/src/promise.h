/*
 * promise.h
 *
 *  Created on: 12 déc. 2018
 *      Author: yoann
 */

#ifndef SRC_PROMISE_H_
#define SRC_PROMISE_H_

#include "shared_result.h"
#include "future.h"

using namespace std;

template <typename T>
using Resptr = shared_ptr<pr::shared_result<T>>;

namespace pr{
	template <typename T>
	class promise{
		Resptr<T> result;
	public:
		promise():result(){}
		future<T> getFuture(){
			return future<T>(result);
		}
		void setValue(const T &r){
			result->set(r);
		}
	};
}


#endif /* SRC_PROMISE_H_ */
