#include "Stack.h"
#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/stat.h>        /* Pour les constantes des modes */
#include <fcntl.h>           /* Pour les constantes O_* */
#include <vector>
#include <sys/mman.h>

#define ANONYME true
#define N 4

using namespace std;
using namespace pr;

vector<pid_t> tokill;

void killall(int sig){
	for(auto p : tokill)
		kill(p, SIGINT);
}

void producteur (Stack<char> * stack) {
	char c ;
	while (cin.get(c)) {
		stack->push(c);
	}
}

void consomateur (Stack<char> * stack) {
	while (true) {
		char c = stack->pop();
		cout << c << flush ;
	}
}

int main () {
	size_t sz = sizeof(Stack<char>);
	int fd;
	void* addr;
	if(ANONYME){
		addr = mmap(nullptr, sz, PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
		if(addr == MAP_FAILED){
			perror("mmap");
			exit(1);
		}
	}else{
		fd = shm_open("/myshm", O_CREAT|O_EXCL|O_RDWR, 0666);
		if(fd == -1){
			perror("shm_open");
			exit(1);
		}
		if(ftruncate(fd, sz) != 0){
			perror("ftruncate");
			exit(1);
		}
		addr = mmap(nullptr, sz, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		if(addr == MAP_FAILED){
			perror("mmap");
			exit(1);
		}
	}
	Stack<char> * s = new (addr) Stack<char>();

	pid_t pp = fork();
	if (pp==0) {
		producteur(s);
		return 0;
	}

	pid_t pc = fork();
	if (pc==0) {
		consomateur(s);
		return 0;
	}else{
		tokill.push_back(pc);
	}

	signal(SIGINT, killall);

	wait(0);
	wait(0);

	s->~Stack();
	if(munmap(addr, sz) != 0){
		perror("munmap");
		exit(1);
	}
	if(!ANONYME)
		if(shm_unlink("/myshm") != 0){
			perror("shm_unlink");
			exit(1);
		}
	return 0;
}

