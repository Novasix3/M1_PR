#pragma once

#include <cstring> // size_t,memset
#include <mutex>
#include <semaphore.h>

using namespace std;

namespace pr {

#define STACKSIZE 100

template<typename T>
class Stack {
	T tab [STACKSIZE];
	size_t sz;
	sem_t mutex, sempush, sempop;

public :
	Stack () : sz(0) {
		memset(tab,0,sizeof tab);
		sem_init(&mutex, 1, 1);
		sem_init(&sempop, 1, 0);
		sem_init(&sempush, 1, STACKSIZE);
	}

	T pop () {
		sem_wait(&sempop);
		sem_wait(&mutex);
		T toret = tab[--sz];
		sem_post(&mutex);
		sem_post(&sempush);
		return toret;
	}

	void push(T elt) {
		sem_wait(&sempush);
		sem_wait(&mutex);
		tab[sz++] = elt;
		sem_post(&mutex);
		sem_post(&sempop);
	}

	~Stack(){
		sem_destroy(&mutex);
		sem_destroy(&sempop);
		sem_destroy(&sempush);
	}
};

}
