#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <ctype.h>

#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* Pour les constantes des modes */
#include <fcntl.h>           /* Pour les constantes O_* */
#include <semaphore.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <errno.h>

#include <string.h>

using namespace std;

int main0(int argc, char** argv){
	int tubeDesc[2];
	pid_t pid_fils;
	if(pipe(tubeDesc) == -1){
		perror("pipe");
		exit(1);
	}

	if((pid_fils = fork()) == -1){
		perror("fork");
		exit(2);
	}

	if(pid_fils == 0){
		dup2(tubeDesc[1], STDOUT_FILENO);
		close(tubeDesc[1]);
		close(tubeDesc[0]);
		char* arg[argc-2];
		arg[argc-2] = nullptr;
		int i = 1;
		while(strcmp(argv[i], "|") != 0){
			arg[i-2] = argv[i];
			i++;
		}
		if(execv(argv[0], arg) == -1){
			perror("execv");
			exit(3);
		}
	}else{
		dup2(tubeDesc[0], STDIN_FILENO);
		close(tubeDesc[1]);
		close(tubeDesc[0]);
		int i = 2;
		while(strcmp(argv[i], "|") != 0)
			i++;
		if(execv(argv[i+1], argv+i+2) == -1){
			perror("execv");
			exit(4);
		}
	}
	return 0;
}


















