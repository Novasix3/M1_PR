/*
 * MTChatRoom.h
 *
 *  Created on: 28 nov. 2018
 *      Author: yoann
 */

#ifndef SRC_MTCHATROOM_H_
#define SRC_MTCHATROOM_H_

#include "IChatRoom.h"
#include <mutex>
#include <vector>

namespace pr {
class MTChatRoom: public IChatRoom {
	IChatRoom* deco;
	mutable std::mutex m;
public:
	MTChatRoom(IChatRoom* cr) :
			deco(cr) {
	}
	;

	std::string getSubject() const {
		std::unique_lock<std::mutex> l(m);
		return deco->getSubject();
	}
	std::vector<ChatMessage> getHistory() const {
		std::unique_lock<std::mutex> l(m);
		return deco->getHistory();
	}

	virtual bool posterMessage(const ChatMessage & msg) {
		std::unique_lock<std::mutex> l(m);
		return deco->posterMessage(msg);
	}

	virtual bool joinChatRoom(IChatter * chatter) {
		std::unique_lock<std::mutex> l(m);
		return deco->joinChatRoom(chatter);
	}

	virtual bool leaveChatRoom(IChatter * chatter) {
		std::unique_lock<std::mutex> l(m);
		return deco->leaveChatRoom(chatter);
	}

	virtual size_t nbParticipants() const {
		std::unique_lock<std::mutex> l(m);
		return deco->nbParticipants();
	}
};
}

#endif /* SRC_MTCHATROOM_H_ */
