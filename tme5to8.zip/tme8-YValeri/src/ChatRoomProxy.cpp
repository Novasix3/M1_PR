/*
 * ChatRoomProxy.cpp
 *
 *  Created on: 28 nov. 2018
 *      Author: yoann
 */

#include "ChatRoomProxy.h"
#include "chat.pb.h"
#include <unistd.h>

namespace pr{
	ChatRoomProxy::ChatRoomProxy(const std::string &host, int port){
		sock.connect(host, port);
	}

	std::string ChatRoomProxy::getSubject() const{
		writeRequest(sock, ChatRoomRequest::SUBJECT);
		GetSubjectResponse resp;
		std::string str = sock.readString();
		resp.ParseFromString(str);
		return resp.msg();
	}

	size_t ChatRoomProxy::getNbParticipants() const{
		pr::writeRequest(sock, ChatRoomRequest::NBPARTICIPANTS);
		GetNbParticipantsResponse resp;
		std::string str = sock.readString();
		resp.ParseFromString(str);
		return resp.nbpart();
	}

	ChatRoomProxy::~ChatRoomProxy(){
		sock.writeInt(2);
		sock.close();
	}

	std::vector<ChatMessage> ChatRoomProxy::getHistory() const{
		writeRequest(sock, ChatRoomRequest::HISTORY);
		GetHistoryResponse resp;
		std::string str = sock.readString();
		resp.ParseFromString(str);
		std::vector<ChatMessage> res;
		res.reserve(resp.history_size());
		for(auto m : resp.history())
			res.push_back(ChatMessage(m.author(), m.msgtext()));
		return res;
	}

	bool ChatRoomProxy::posterMessage(const ChatMessage &msg){
		return true;
	}

	bool ChatRoomProxy::joinChatRoom(IChatter* c){
		return true;
	}

	bool ChatRoomProxy::leaveChatRoom(IChatter * chatter){
		return true;
	}

	bool writeRequest(Socket &s, ChatRoomRequest::Request red){
		ChatRoomRequest crr;
		crr.set_req(red);
		std::string str;
		crr.SerializeToString(&str);
		s.writeString(str);
		return true;
	}

}


