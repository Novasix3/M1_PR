#include "TextChatRoom.h"

using namespace pr;
using namespace std;

int main() {
	IChatRoom * cr = new TextChatRoom("C++");
	TextChatter alice("alice");
	TextChatter bob("bob");
	cr->joinChatRoom(&alice);
	cr->joinChatRoom(&bob);
	cr->posterMessage( { "bob", "salut" });
	cr->posterMessage( { "alice", "hello" });
	cr->posterMessage( { "alice", "bye" });
	cr->leaveChatRoom(&alice);

	cr->posterMessage( { "bob", "reste !" });
	cr->leaveChatRoom(&bob);

	delete cr;

}
