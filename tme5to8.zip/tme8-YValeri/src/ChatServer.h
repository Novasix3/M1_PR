/*
 * ChatRoomServer.h
 *
 *  Created on: 28 nov. 2018
 *      Author: yoann
 */

#ifndef SRC_CHATSERVER_H_
#define SRC_CHATSERVER_H_

#include "IChatRoom.h"
#include "TCPServer.h"

namespace pr{
	class ChatServer{
		TCPServer server;
	public:
		ChatServer(IChatRoom* cr, int port);
		~ChatServer();
	};
}



#endif /* SRC_CHATROOMSERVER_H_ */
