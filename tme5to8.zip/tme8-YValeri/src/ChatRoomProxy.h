/*
 * ChatRoomProxy.h
 *
 *  Created on: 28 nov. 2018
 *      Author: yoann
 */

#ifndef SRC_CHATROOMPROXY_H_
#define SRC_CHATROOMPROXY_H_

#include "IChatRoom.h"
#include "Socket.h"

namespace pr{
	class ChatRoomProxy: public IChatRoom{
		mutable Socket sock;
	public:
		ChatRoomProxy(const std::string &host, int port);
		std::string getSubject() const;
		size_t getNbParticipants() const;
		~ChatRoomProxy();
		std::vector<ChatMessage> getHistory() const;
		bool posterMessage(const ChatMessage &msg);
		bool joinChatRoom(IChatter* c)
		bool leaveChatRoom(IChatter * chatter);
	};
}



#endif /* SRC_CHATROOMPROXY_H_ */
