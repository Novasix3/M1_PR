/*
 * chatServer.cpp
 *
 *  Created on: 28 nov. 2018
 *      Author: yoann
 */

#include "ChatServer.h"
#include "chat.pb.h"
#include <unistd.h>
#include <string>
#include <iostream>

namespace pr {
class ChatRoomCH: public ConnectionHandler {
	IChatRoom* cr;
public:
	ChatRoomCH(IChatRoom* cr) :
			cr(cr) {
	}

	void handleConnection(Socket s) {
		while (1) {
			ChatRoomRequest crr;
			std::string str = s.readString();
			crr.ParseFromString(str);
			switch (crr.req()) {
			case ChatRoomRequest::SUBJECT: {
				GetSubjectResponse respS;
				respS.set_msg(cr->getSubject());
				respS.SerializeToString(&str);
				s.writeString(str);
				break;
			}
			case ChatRoomRequest::HISTORY: {
				GetHistoryResponse respH;
				for (auto &m : cr->getHistory()) {
					ChatMessagePB* mpb = respH.add_history();
					mpb->set_author(m.getAuthor());
					mpb->set_msgtxt(m.getMessage());
				}
				respH.SerializeToString(&str);
				s.writeString(str);
				break;
			}
			case ChatRoomRequest::NBPARTICIPANTS: {
				GetNbParticipantsResponse respN;
				respN.set_nbpart(cr->nbParticipants());
				respN.SerializeToString(&str);
				s.writeString(str);
				break;
			}
			case ChatRoomRequest::QUIT:
				std::cout << "fin depuis client" << std::endl;
				return;
			default:
				std::cerr << "message inconnu : " << crr.req() << std::endl;
			}

		}
	}

	ConnectionHandler* clone() const {
		return new ChatRoomCH(*this);
	}

}
;

ChatServer::ChatServer(IChatRoom* cr, int port) :
		server(new ChatRoomCH(cr)) {
	server.startServer(port);
}

ChatServer::~ChatServer() {
	server.stopServer();
}
}
