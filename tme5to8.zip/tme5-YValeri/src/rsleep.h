#ifndef __RSLEEP_H__
#define __RSLEEP_H__

void randsleep();

#endif
