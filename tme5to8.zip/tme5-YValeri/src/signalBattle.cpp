#include <iostream>
#include <unistd.h>
#include <sys/wait.h>
#include <cstdlib>

#include "rsleep.h"

using namespace std;

int life = 3;
pid_t vador;

void attaque(pid_t adversaire){
	signal(SIGINT, [](int sig){
		life--;
		if(getpid() == vador){
			cout << "Vador" << getpid() << endl ;
			cout << "Vador a été touché -> HP = " << life << endl;
			if(life <= 0){
				cout << "Vador est mort" << endl;
				exit(0);
			}
		}else{
			cout << "Luke : " << getpid() << endl ;
			cout << "Luke a été touché -> HP = " << life << endl;
			if(life <= 0){
				cout << "Luke est mort" << endl;
				exit(0);
			}
		}
	});
	if(kill(adversaire, SIGINT) == -1)
		exit(0);
	randsleep();
}

void sig_hand(int sig){
	cout << "coup paré" << endl;
}

void defense(){
	/*if(getpid() != vador){
		sigset_t sig_proc;
		struct sigaction action;
		sigemptyset(&sig_proc);
		action.sa_mask = sig_proc;
		action.sa_flags = 0;
		action.sa_handler = sig_hand;
		sigaction(SIGINT, &action, NULL);
		sigaddset(&sig_proc, SIGINT);
		sigprocmask(SIG_SETMASK, &sig_proc, NULL);
		randsleep();

		sigpending(&sig_proc);
		if(sigismember(&sig_proc, SIGINT))
			cout << "coup paré" << endl;

		//Le combat n'est ainsi plus équitable car Luke bloque tout SIGINT par sigprocmask
		//et donc ne prendra jamais de coup
	}else{*/
		signal(SIGINT, [](int sig){
				if(getpid() == vador){
					cout << "Vador" << getpid() << endl ;
					cout << "Vador a paré -> HP = " << life << endl;
				}else{
					cout << "Luke" << getpid() << endl ;
					cout << "Luke a paré -> HP = " << life << endl;
				}
			});
		randsleep();
	//}
}

void combat(pid_t adversaire){
	while(true){
		cout << ((adversaire == vador)?"Luke combat !":"Vador combat !") << " (avec le pid = " << getpid() <<")" << endl;
		attaque(adversaire);
		defense();
	}
}

int main () {
	//cout << "slt" << endl;
	signal(SIGINT, SIG_IGN);
	vador = getpid();
	pid_t luke = fork();
	cout << "pid = " << getpid() << endl;
	randsleep();
	srand(luke);
	if(luke == 0)
		combat(vador);
	else
		combat(luke);

	return 0;
}



















