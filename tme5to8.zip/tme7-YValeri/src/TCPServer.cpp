#include "TCPServer.h"
#include <unistd.h>
#include <iostream>

using namespace std;

namespace pr{
	bool TCPServer::startServer(int port){
		ServerSocket* ss = new ServerSocket(port);
		if(ss->isOpen()){
			while(1){
				cout << "connected" << endl;
				pr::Socket sc = ss->accept();
				if(sc.isOpen()){
					auto copy = handler->clone();
					copy->handleConnection(sc);
					delete copy;
				}
			}
			return true;
		}
		return false;
	}
}
