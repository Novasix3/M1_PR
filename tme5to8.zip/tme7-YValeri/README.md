# TME7

Plus ou moins compatible CDT project, car génère plusieurs executables.

Compatible autoconf/automake, exécuter cette séquence d'opérations
après le clone :

```
autoreconf -vfi
./configure 
make
```

Les fois suivantes simplement invoquer "make".
