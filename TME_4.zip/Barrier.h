#ifndef SRC_BARRIER_H
#define SRC_BARRIER_H

#include <mutex>
#include <condition_variable>

using namespace std;

class Barrier
{
	mutable mutex m;
	int cpt;
	int N;
	condition_variable cv;
public:
	Barrier(int n):cpt(0, N(n){}
	~Barrier();

	void done() {
		unique_lock<mutex> ul(m);
		++cpt;
		if (cpt == N)
			cv.notify_all();
	}

	void waitFor() {
		unique_lock<mutex> ul(m);
		while (cpt != N)
			cv.wait();
	}
};

#endif