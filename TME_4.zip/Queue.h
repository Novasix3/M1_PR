#ifndef SRC_QUEUE_H
#define SRC_QUEUE_H

#include <string>
#include <mutex>
#include <condition_variable>

using namespace std;

template <typename T>
class Queue
{
	T** tab;
	const size_t allocsize;
	size_t begin;
	size_t sz;
	mutable mutex m;
	condition_variable cvp, cvc;
	bool isBlocking;

	bool full() const {
		return sz == allocsize;
	}

	bool empty() const {
		return sz == 0;
	}

public:
	Queue(size_t maxsize) : allocsize(maxsize), begin(0), sz(0), isBlocking(true) {
		tab = new T*[maxsize];
		memset(tab, 0, maxsize * sizeof(T*));
	}

	size_t size() const {
		lock_guard<mutex> lg(m);
		return sz;
	}

	T* pop() {
		unique_lock<mutex> ul(m);
		while (empty() && isBlocking)
			cvp.wait(ul);
		if (full())
			cvc.notify_all();
		auto ret = tab[begin];
		tab[begin] = nullptr;
		sz--;
		begin = (begin + 1) % allocsize;
		return ret;
	}

	bool push(T* elt) {
		unique_lock<mutex> ul(m);
		while (full())
			cvc.wait(ul);
		if (empty())
			cvp.notify_all();
		tab[(begin + sz) % allocsize] = elt;
		sz++;
		return true;
	}

	~Queue() {
		for (size_t i = 0; i < sz; ++i) {
			auto ind = (begin + i) % allocsize;
			delete tab[ind];
		}
		delete[] tab;
	}

	void setBlockingPool(bool isBlocking) {
		unique_lock<mutex> ul(m);
		this->isBlocking = isBlocking;
		cvp.notify_all();
		cvc.notify_all();
	}
};

#endif 