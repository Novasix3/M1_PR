#include "Job.h"



Job::Job()
{
}


Job::~Job()
{
}
