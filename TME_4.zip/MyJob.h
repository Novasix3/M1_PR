#ifndef SRC_MYJOB_H
#define SRC_MYJOB_H

#include "Job.h"
#include "Barrier.h"

#include <thread>
#include <iostream>

using namespace std;

class MyJob:public Job
{
	int arg;
	int* ret;
	Barrier* b;
	
	int foo(int arg) {
		this_thread::sleep_for(chrono::milliseconds(1000));
		return arg % 256;
	}
public:
	MyJob(int arg, int* ret, Barrier* barrier):arg(arg), ret(ret), b(barrier){}
	~MyJob(){}

	void run() {
		cout << "d�but sur arg = " << arg << endl;
		*ret = foo(arg);
		cout << "ret = " << *ret << endl;
		b->done();
	}
};

#endif