#include <cstdlib>
#include <iostream>
#include <fstream>
#include <thread>
#include <unistd.h>
#include <chrono>
#include <sys/wait.h>
#include <vector>
#include <mutex>
#include <condition_variable>

using namespace std;

void reverse_random(int N){
	ofstream hasardW;
		remove("hasard.txt");
		hasardW.open("hasard.txt");
		pid_t sons[N];
		int i;
		for(i = 0; i < N; ++i){
			pid_t pid = fork();
			if(pid == 0){
				srand(time(0));
				cout << rand() << endl;
				int x = rand() % N;
				if(i == N-1)
					cout << "le dernier va commencer " << getpid() << " avec x = " << x << endl;
				else
					cout << "va commencer " << getpid() << " avec x = " << x << endl;
				this_thread::sleep_for(chrono::seconds(x));
				if(i == N-1)
					hasardW << x << "blavbl" << endl;
				else
					hasardW << x << endl;
				hasardW.close();
				cout << getpid() << " s'est fini" << endl;
				exit(0);
			}else
				sons[i] = pid;
		}
		hasardW.close();
		int j;
		for(j = 0; j < N; ++j)
			wait(nullptr);
		ifstream hasardR;
		hasardR.open("hasard.txt");
		vector<string> reverse_line;
		string line;
		while(getline(hasardR, line)){
			reverse_line.insert(reverse_line.begin(), line);
		}
		for(i = i - 1; i >= 0; --i){
			cout << sons[i] << " and " << reverse_line[i] << endl;
		}
}
mutex m;
bool win;
condition_variable turn;
int draw1, draw2, result1, result2;

bool play(int* draw, int* result){
	*draw += 1;
	srand(*draw);
	int a = rand();
	srand(*result);
	int b = rand();
	cout << "a = " << a << ", b = " << b << endl;
	if(a%2 == b%2){
		*result += 1;
		return true;
	}
	return false;
}

void player(bool start){
	unique_lock<mutex> lg(m);
	while(win != true){
		cout << "result1 = " << result1 << ", draw1 = " << draw1 << endl;
		cout << "result2 = " << result2 << ", draw2 = " << draw2 << endl;
		if(start){
			cout << "le premier thread a tiré " << endl;
			while(play(&draw1, &result1) && result1 != 10)
				cout << "le premier thread a tiré " << endl;
			if(result1 == 10)
				win = true;
		}else{
			cout << "le second thread a tiré " << endl;
			while(play(&draw2, &result2) && result2 != 10)
				cout << "le second thread a tiré " << endl;
			if(result2 == 10)
				win = true;
		}
		cout << "sorti du play" << endl;
		turn.notify_one();
		if(win)
			break;
		turn.wait(lg);
	}
}

void take_your_turn(){
	win = false;
	vector<thread> players;
	players.reserve(2);
	srand(time(0));
	int a = rand();
	cout << "slt" << endl;
	players.emplace_back(player, a%2);
	players.emplace_back(player, (a+1)%2);
	cout << "slt2" << endl;
	players[0].join();
	players[1].join();
	cout << "slt3" << endl;
	cout << "Le premier joueur a fait " << draw1 << "tirages et obtenu " << result1 << " points." << endl;

	cout << "Le second joueur a fait " << draw2 << "tirages et obtenu " << result2 << " points." << endl;
}

int main(){
	//reverse_random(10);
	take_your_turn();
	return 0;
}


