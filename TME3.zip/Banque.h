#pragma once

#include <vector>
#include <iostream>
#include <thread>

#include "Compte.h"

using namespace std;

class Banque
{
	int initial;
	thread comptable;
public:
	vector<Compte> comptes;
	Banque(int, int);
	~Banque();
	size_t size() const;
	void print() const;
};

