
#include <thread>
#include <cstdlib>
#include <chrono>

#include "Banque.h"


Banque::Banque(int nb, int si): comptes(nb, Compte(si)), initial(si){}

Banque::~Banque() {}

size_t Banque::size() const {
	return comptes.size();
}

void Banque::print() const {
	std::cout << std::endl << "Voici l'etat des comptes courant." << std::endl;
	for (auto& c : comptes)
		std::cout << c.getSolde() << std::endl;
}
