
#include "Compte.h"

using namespace std;


Compte::Compte(int solde = 0): solde(solde) {}

Compte::Compte(const Compte& other){
	lock_guard<recursive_mutex> lg(m);
	solde = other.getSolde();
}

Compte::~Compte(){}

void Compte::crediter(int val) {
	lock_guard<recursive_mutex> lg(m);
	solde += val;
}

bool Compte::debiter(int val) {
	lock_guard<recursive_mutex> lg(m);
	bool go = (solde >= val);
	if (go) solde -= val;
	return go;
}

int Compte::getSolde() const {
	lock_guard<recursive_mutex> lg(m);
	return solde;
}

recursive_mutex& Compte::getMutex() const{
	return std::ref(m);
}

void Compte::lock() const {
	m.lock();
}

void Compte::unlock() const {
	m.unlock();
}

bool Compte::try_lock() const {
	return m.try_lock();
}

/* //Question 10
void Compte::crediter(int val) {
	m.lock();
	solde += val;
	m.unlock();
}

bool Compte::debiter(int val) {
	m.lock();
	bool go = (solde >= val);
	if (go) solde -= val;
	m.unlock();
	return go;
}

int Compte::getSolde() const {
	m.lock();
	int s = solde;
	m.unlock();
	return s;
}*/

/* //Question 1 -> 9
void Compte::crediter(int val) {
	solde += val;
}

bool Compte::debiter(int val) {
	bool go = (solde >= val);
	if (go) solde -= val;
	return go;
}

int Compte::getSolde() const {
	return solde;
}
*/