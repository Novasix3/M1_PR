#pragma once

#include <atomic>
#include <mutex>

using namespace std;

class Compte
{
	atomic<int> solde;
	mutable recursive_mutex m;
public:
	Compte(int);
	Compte(const Compte& other);
	~Compte();
	void crediter(int);
	bool debiter(int);
	int getSolde() const;
	recursive_mutex& getMutex() const;
	void lock() const;
	void unlock() const;
	bool try_lock() const;
};

