#include <iostream>

#include <gmpxx.h> //On inclut la bibliothèque gmp
#include <chrono>
#include <vector>
#include "Arithmpz.h"

#define MAX 10 //On affichera MAX nombres premiers...
#define MPZ mpz_class

using namespace std;
using namespace model;

mpz_class* mul(const mpz_class P[], const mpz_class Q[], const mpz_class size1, const mpz_class size2){
	
	mpz_class size(size1.get_ui() * size2.get_ui() - 2);
	
	mpz_class *R = new mpz_class[size.get_ui()];
	
	for(mpz_class i=0; i<size1.get_ui(); i++){
		
		for(mpz_class j=0; j<size2.get_ui(); j++){
		
			mpz_class a(P[i.get_ui()]);
			mpz_class b(Q[j.get_ui()]);
			
			std::cout << "a = " << a.get_ui() << std::endl;
			std::cout << "b = " << b.get_ui() << std::endl;
			std::cout << "a*b = " << a.get_ui() * b.get_ui() << std::endl;
			
			mpz_class c(size.get_ui()-i.get_ui()-j.get_ui()-1);
			std::cout << "c = " << c.get_ui() << std::endl;
			
			R[c.get_ui()] += a.get_ui() * b.get_ui();
		}
    }
    
    for(mpz_class i=size.get_ui()-1; i>=0; i--)
		std::cout << std::endl<< "R = " << R[i.get_ui()]  << std::endl<< std::endl;
    
	return R;
}


void show(vector<MPZ> vect){
	cout << endl;
	cout << endl;
	cout << "On affiche vect : ";
	for(auto v : vect){
		cout << v << " ";
	}
	cout << endl;
	cout << endl;
	cout << endl;
}

MPZ two(2);

pair<vector<MPZ>, vector<MPZ>> split(vector<MPZ> vect){
	int power = vect.size()/2;
	cout << "power = " << power << endl;
	vector<MPZ> funder(power);
	for(int i = 0; i < power; ++i){
		cout << "vect[i] = vect[" << i << "] = " << vect[i] << endl;
		funder[i] = vect[i];
	}
	vector<MPZ> fupper(power);
	for(int i = 0; i < power; ++i){
		cout << "vect[i+power+1] = vect[" << i+power << "] = " << vect[i+power] << endl;
		fupper[i] = vect[i+power];
	}
	pair <vector<MPZ>, vector<MPZ>> res = make_pair(funder, fupper);
	return res;
}

vector<MPZ> assemble(vector<MPZ> h0, vector<MPZ> h2, vector<MPZ> h){
	vector<MPZ> res(h.size()*2 + 1);
	cout << "ygifhdoqgbfiuqsidghiuisdfgbhifdnbifnbi res.size() = " << res.size() <<endl;
	for(int i = 0; i < h0.size(); ++i){
		cout << "h0[i] = " << h0[i] << endl;
		res[i] = h0[i];
		cout << "res[i] = res[" << i << "] = " << res[i] << endl;
	}
	show(res);
	for(int i = 0; i < h2.size(); ++i){
		cout << "h2[i] = " << h2[i] << endl;
		res[res.size() - 1 - i] += h2[h2.size() - 1 - i];
		cout << "res[i+h0.size()+h.size()] = res[" << i << "] = " << res[i] << endl;
	}
	show(res);
	for(int i = 0; i < h.size(); ++i){
		cout << "h[i] = " << h[i] << endl;
		res[i+h0.size()-1] += h[i];
		cout << "res[i+h0.size()] = res[" << i << "] = " << res[i] << endl;
	}
	return res;
}

vector<MPZ> karatsuba(vector<MPZ> P, vector<MPZ> Q){
	if(P.size() == 2){
		vector<MPZ> res(3);
		res[0] = P[0] * Q[0];
		res[2] = P[1] * Q[1];
		res[1] = (P[0] + P[1]) * (Q[0] + Q[1]) - res[0] - res[2];
		return res;
	}
	pair<vector<MPZ>, vector<MPZ>> f(split(P));
	pair<vector<MPZ>, vector<MPZ>> g(split(Q));
	show(f.first);
	show(f.second);
	show(g.first);
	show(g.second);
	vector<MPZ> h0(karatsuba(f.first, g.first));
	vector<MPZ> h2(karatsuba(f.second, g.second));
	cout << "h0 = ";
	show(h0);
	cout << "h2 = ";
	show(h2);
	vector<MPZ> h(model::sub(karatsuba(model::add(f.first, f.second), model::add(g.first, g.second)), h0, h2));
	cout << "h = ";
	show(h);
	vector<MPZ> res(assemble(h0, h2, h));
	show(res);
	return res;
}

int main(int argc, char **argv)

{ 
     //P[0] = coef du degré 0
     
     // (4x2+3x+1) * (7x+4) = 28x3+16x2+21x2+12x+7x+4 = 28x3+37x2+19x+4
     
	// (-3x3+4x2+3x+1) * (6x3+2x2+7x+4) = -18x6 - 6x5 - 21x4 - 12x3 + 24x5 + 8x4 + 28x3 + 16x2 + 18x4 + 6x3 + 21x2 + 12x + 6x3 + 2x2 + 7x + 4
	// = -18x6  + 18x5 + 5x4 + 28x3 + 39x2 + 19x + 4
	vector<MPZ> P(4);
	P[0] = 1;
	P[1] = 3;
	P[2] = 4;
	P[3] = -3;
	
	vector<MPZ> Q(4);
	Q[0] = 4;
	Q[1] = 7;
	Q[2] = 2;
	Q[3] = 6;
	
	show(model::add(P, Q));
	karatsuba(P, Q);

    return 0;

}
