#ifndef ARITHMPZ_H_
#define ARITHMPZ_H_

#include <cstdlib>
#include <iostream>

#include <gmpxx.h>

#define PRIME 7

using namespace std;

namespace model{
	class Arithmpz{
		public:
			friend mpz_class operator+(const mpz_class a,const mpz_class b);
			friend mpz_class operator*(const mpz_class a,const mpz_class b);
			friend mpz_class operator/(const mpz_class a,const mpz_class b);
	};
}



#endif
