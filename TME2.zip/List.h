#ifndef LIST_H_
#define LIST_H_

#include <cstdlib>
#include <iostream>

namespace pr {
	template <typename T>
	class List{
		struct Node{
		public:
			T data;
			Node* next;
		};
		Node* head;
		class ListIT{
			Node* cur;
		public:
			ListIT(Node* ptr = nullptr):cur(ptr){}
			T& operator* () const{
				return cur->data;
			}
			T* operator-> () const{
				return &(cur->data);
			}
			ListIT& operator++ (){
				cur = cur->next;
				return *this;
			}
			bool operator != (const ListIT& li){
				return cur != li.cur;
			}
		};
	public:
		typedef ListIT iterator;
		List():head(nullptr){}
		virtual ~List(){
			Node* ptr = head;
			while(ptr != nullptr){
				Node* tmp = ptr->next;
				delete ptr;
				ptr = tmp;
			}
		}

		void push_front(const T& data){
			head = new Node{data, head};
		}
		void push_back(const T& data){
			if(head == nullptr)
				push_front(data);
			Node* tail = head;
			while(tail->next)
				tail = tail->next;
			tail->next = new Node{data, nullptr};
		}
		bool empty() const{
			return head == nullptr;
		}
		iterator end() const{
			return nullptr;
		}
		iterator begin() const{
			return head;
		}
		size_t size() const{
			size_t cpt = 0;
			Node* tmp = head;
			while(tmp != nullptr){
				cpt++;
				tmp = tmp->next;
			}
			return cpt;
		}
		friend std::ostream& operator<<(std::ostream &os,const List<T> &l){
			for (T val :  l) {
				os << val;
				os << "->";
			}
			return os << std::endl;
		}
	};
}


#endif /* LIST_H_ */
