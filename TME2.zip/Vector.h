#ifndef VECTOR_H_
#define VECTOR_H_

#include <cstdlib>
#include <iostream>

namespace pr {
	template <typename T>
	class Vector{
		size_t ssize;
		size_t cap;
		T* tab;
		void verif(){
			if(ssize+1 > cap){
				T* tmp = new T[ssize * 2];
				for(size_t i = 0; i < ssize; ++i)
					tmp[i] = tab[i];
				delete [] tab;
				tab = tmp;
			}
		}
		class VectorIT{
			T* cur;
				public:
					VectorIT(T* ptr = nullptr):cur(ptr){}
					T& operator* () const{
						return *cur;
					}
					T* operator-> () const{
						return *cur;
					}
					VectorIT& operator++ (){
						cur++;
						return *this;
					}
					bool operator != (const VectorIT& li){
						return cur != li.cur;
					}
				};
	public:
		typedef VectorIT iterator;
		Vector(size_t size=10):ssize(0), cap(size){
			tab = new T[cap];
		}
		virtual ~Vector(){
			delete [] tab;
		}
		T& operator[](size_t i) const{
			return tab[i];
		}
		size_t size() const{
			return ssize;
		}
		bool empty() const{
			return ssize == 0;
		}
		void push_back(const T& val){
			verif();
			tab[ssize++] = val;
		}
		iterator end() const{
			return nullptr;
		}
		iterator begin() const{
			return tab;
		}
		friend std::ostream& operator<<(std::ostream &os,const Vector<T> &v){
			os << "[";
			for (T val :  v) {
				os << val;
				os << ",";
			}
			os << "]" << std::endl;
			return os;
		}

	};
}



#endif /* VECTOR_H_ */
