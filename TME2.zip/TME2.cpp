#include <iostream>

#include <gmpxx.h> //On inclut la bibliothèque gmp
#include <chrono>
#include "Arithmpz.h"

#define MAX 10 //On affichera MAX nombres premiers...
#define PRIME 7
  
void multiply(mpz_class F[2][2], mpz_class M[2][2]); 
  
void power(mpz_class F[2][2], mpz_class n); 

mpz_class fibo3(mpz_class n) 
{ 
 	mpz_class un(1), zero(0);
  mpz_class F[2][2] = {{un,un},{un,zero}}; 
  if (n == 0) 
    return 0; 
  power(F, n-1); 
  return F[0][0]; 
} 
  

void power(mpz_class F[2][2], mpz_class n) 
{ 
  if( n == 0 || n == 1) 
      return; 
  mpz_class M[2][2] = {{1,1},{1,0}}; 
  
  power(F, n/2); 
  multiply(F, F); 
  
  if (n%2 != 0) 
     multiply(F, M); 
} 
  
void multiply(mpz_class F[2][2], mpz_class M[2][2]) 
{ 
  mpz_class x =  F[0][0]*M[0][0] + F[0][1]*M[1][0]; 
  mpz_class y =  F[0][0]*M[0][1] + F[0][1]*M[1][1]; 
  mpz_class z =  F[1][0]*M[0][0] + F[1][1]*M[1][0]; 
  mpz_class w =  F[1][0]*M[0][1] + F[1][1]*M[1][1]; 
  
  F[0][0] = x; 
  F[0][1] = y; 
  F[1][0] = z; 
  F[1][1] = w; 
} 

mpz_class fibo2(mpz_class n){
	mpz_class a(1), b(2);
	for(mpz_class i = 3; i < n; i++){
		mpz_class temp = a;
		a = b;
		b = temp + b;
	}
	return (a<b)?b:a;
}

void fib(long unsigned int n){
	mpz_t res;
	mpz_init(res);
	mpz_fib_ui(res, n);
    	std::cout << "fibo(7) = " << res << std::endl;
	
}

mpz_class* add(const mpz_class P[], const mpz_class Q[], const mpz_class size1, const mpz_class size2){
	
	mpz_class size(std::max(size1.get_ui(), size2.get_ui()) );
	
	mpz_class *R = new mpz_class[size.get_ui()];
	
	for(mpz_class i=0; i<size.get_ui(); i++){
		
		mpz_class a;
		mpz_class b;
		
		if(size.get_ui() >= size1.get_ui())
			a = P[i.get_ui()];
		else
			a = 0;
		
    	std::cout << "a = " << a << std::endl;
			
		if(size.get_ui() >= size2.get_ui())
			b = Q[i.get_ui()];
		else
			b = 0;
			
		std::cout << "b = " << b << std::endl;
		
		R[i.get_ui()] = a + b;
		
    	std::cout << "R = " << R[i.get_ui()]  << std::endl;
    }
    
	return R;
}

mpz_class* mul(const mpz_class P[], const mpz_class Q[], const mpz_class size1, const mpz_class size2){
	
	mpz_class size(size1.get_ui() * size2.get_ui() - 2);
	
	mpz_class *R = new mpz_class[size.get_ui()];
	
	for(mpz_class i=0; i<size1.get_ui(); i++){
		
		for(mpz_class j=0; j<size2.get_ui(); j++){
		
			mpz_class a(P[i.get_ui()]);
			mpz_class b(Q[j.get_ui()]);
			
			std::cout << "a = " << a.get_ui() << std::endl;
			std::cout << "b = " << b.get_ui() << std::endl;
			std::cout << "a*b = " << a.get_ui() * b.get_ui() << std::endl;
			
			mpz_class c(size.get_ui()-i.get_ui()-j.get_ui()-1);
			std::cout << "c = " << c.get_ui() << std::endl;
			
			R[c.get_ui()] += a.get_ui() * b.get_ui();
		}
    }
    
    for(mpz_class i=size.get_ui()-1; i>=0; i--)
		std::cout << std::endl<< "R = " << R[i.get_ui()]  << std::endl<< std::endl;
    
	return R;
}

mpz_class* div(const mpz_class P[], const mpz_class Q[], const mpz_class size){
	mpz_class *R = new mpz_class[size.get_ui()];
	for(mpz_class i=0; i<size.get_ui(); i++){
		mpz_mod (R[i.get_ui()].get_mpz_t(), P[i.get_ui()].get_mpz_t(), Q[i.get_ui()].get_mpz_t());
    	std::cout << P[i.get_ui()] <<"/" << Q[i.get_ui()] << " = " << P[i.get_ui()] / Q[i.get_ui()] << std::endl;
    	std::cout << "R = " << R[i.get_ui()]  << std::endl;
    }
    	std::cout << "4/13 = " << 4/13  << std::endl;
    
	return R;
}


int main(int argc, char **argv)

{ 
     
    mpz_class size1 = 3;
	mpz_class *P = new mpz_class[size1.get_ui()];
	P[0] = 1;
	P[1] = 3;
	P[2] = 4;
	
	mpz_class size2 = 2;
	mpz_class *Q = new mpz_class[size2.get_ui()];
	Q[0] = 4;
	Q[1] = 7;
	/*for(mpz_class i=0; i<size.get_ui(); i++){
		P[i.get_ui()] = i+3;
    	//std::cout << "P = " << P[i.get_ui()]  << std::endl;
    }
	
	mpz_class *Q = new mpz_class[size.get_ui()];
	for(mpz_class i=0; i<size.get_ui(); i++){
		Q[i.get_ui()] = i+12;
		//std::cout << "Q = " << Q[i.get_ui()]  << std::endl;
    }*/
	
	//mpz_class* R = add(P, Q, size, size);
	mpz_class* R = mul(P, Q, size1, size2);
	//R = div(P, Q, size);

    return 0;

}
