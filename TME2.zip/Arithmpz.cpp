#include "Arithmpz.h"
	

namespace model{
	mpz_class operator+(const mpz_class a,const mpz_class b){
		mpz_t res;
		mpz_init(res);
    	std::cout << "slt" << std::endl;
		
		mpz_add (res, a.get_mpz_t(), b.get_mpz_t());
		
		mpz_class p(PRIME);
		
		mpz_mod (res, res, p.get_mpz_t());
		return mpz_class(res);
	}
	
	mpz_class operator*(const mpz_class a,const mpz_class b){
		mpz_t res;
		mpz_init(res);
    	std::cout << "slt2" << std::endl;
		
		mpz_mul (res, a.get_mpz_t(), b.get_mpz_t());
		
		mpz_class p(PRIME);
		
		mpz_mod (res, res, p.get_mpz_t());
		return mpz_class(res);
	}
	
	mpz_class operator/(const mpz_class a,const mpz_class b){
		mpz_t res;
		mpz_init(res);
    	std::cout << "slt3" << std::endl;
		
		mpz_cdiv_q (res, a.get_mpz_t(), b.get_mpz_t());
		
		mpz_class p(PRIME);
		
		mpz_mod (res, res, p.get_mpz_t());
		return mpz_class(res);
	}
}


